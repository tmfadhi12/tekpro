package com.java.praktikum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PraktikumApplication {

	public static void main(String[] args) {
		SpringApplication.run(PraktikumApplication.class, args);
	}

}
