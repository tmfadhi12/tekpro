package com.java.praktikum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PraktikumApplicationTests {

	@Test
	void contextLoads() {
	}

}
